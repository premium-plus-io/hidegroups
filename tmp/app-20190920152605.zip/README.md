# Delegate Plus - Hide Ticket Groups	

This apps hides ticket groups from the groups dropdown. This way agent's can't assign tickets to these groups.

### Screenshot(s):
!()[screenshot-0.png]
!()[screenshot-1.png]
!()[screenshot-2.png]
!()[screenshot-3.png]